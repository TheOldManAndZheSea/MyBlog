<template>
  <div class="app-container">
    <!-- :model属性用于表单验证使用 比如下面的el-form-item 的 prop属性用于对表单值进行验证操作 -->
    <el-form :model="queryParams" size="small" label-position="right" inline ref="queryForm" :label-width="labelWidth" v-show="showSearch" 
      @submit.native.prevent>
      
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <!-- 工具区域 -->
    <el-row :gutter="10" class="mb8">
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <!-- 数据区域 -->
    <el-table :data="dataList" v-loading="loading" ref="table" border highlight-current-row @sort-change="sortChange" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="50" align="center"/>
      <el-table-column prop="id" label="id" align="center" />
      <el-table-column prop="name" label="姓名" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="sex" label="性别" align="center">
        <template slot-scope="scope">
          <dict-tag :options="sexOptions" :value="scope.row.sex" />
        </template>
      </el-table-column>
      <el-table-column prop="age" label="年龄" align="center" />
      <el-table-column prop="degree" label="学历" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="height" label="身高cm" align="center" />
      <el-table-column prop="weight" label="体重kg" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="birthday" label="出生日期" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="school" label="学校" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="specialized" label="专业" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="blood" label="血型" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="giteeUrl" label="码云地址" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="gitHubUrl" label="Github地址" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="cSDNUrl" label="CSDN博客地址" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="email" label="邮箱" align="center" :show-overflow-tooltip="true" />
      <el-table-column prop="avatar" label="头像" align="center">
        <template slot-scope="scope">
          <el-image class="table-td-thumb" fit="contain" :src="scope.row.avatar" :preview-src-list="[scope.row.avatar]">
            <div slot="error"><i class="el-icon-document" /></div>
          </el-image>
        </template>
      </el-table-column>

      <el-table-column label="操作" align="center" width="140">
        <template slot-scope="scope">
        </template>
      </el-table-column>
    </el-table>
    <pagination class="mt10" background :total="total" :page.sync="queryParams.pageNum" :limit.sync="queryParams.pageSize" @pagination="getList" />

    <!-- 添加或修改博客个人信息对话框 -->
    <el-dialog :title="title" :lock-scroll="false" :visible.sync="open" >
      <el-form ref="form" :model="form" :rules="rules" :label-width="formLabelWidth">
        <el-row :gutter="20">
    <el-col :lg="12" v-if="opertype == 2">
      <el-form-item label="id">{{form.id}}</el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="姓名" prop="name">
        <el-input v-model="form.name" placeholder="请输入姓名" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="性别" prop="sex">
        <el-select v-model="form.sex" placeholder="请选择性别"> 
          <el-option v-for="item in sexOptions" :key="item.dictValue" :label="item.dictLabel" :value="item.dictValue"></el-option>
        </el-select>
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="年龄" prop="age">
        <el-input-number v-model.number="form.age" controls-position="right" placeholder="请输入年龄" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="学历" prop="degree">
        <el-input v-model="form.degree" placeholder="请输入学历" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="身高cm" prop="height">
        <el-input-number v-model.number="form.height" controls-position="right" placeholder="请输入身高cm" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="体重kg" prop="weight">
        <el-input-number v-model.number="form.weight" controls-position="right" placeholder="请输入体重kg" />
      </el-form-item>
    </el-col>
      <el-col :lg="12">
        <el-form-item label="出生日期" prop="birthday">
           <el-date-picker v-model="form.birthday" format="yyyy-MM-dd HH:mm:ss" value-format="yyyy-MM-dd HH:mm:ss" type="datetime" placeholder="选择日期时间"> </el-date-picker>
         </el-form-item>
     </el-col>
    <el-col :lg="12">
      <el-form-item label="学校" prop="school">
        <el-input v-model="form.school" placeholder="请输入学校" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="专业" prop="specialized">
        <el-input v-model="form.specialized" placeholder="请输入专业" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="血型" prop="blood">
        <el-input v-model="form.blood" placeholder="请输入血型" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="码云地址" prop="giteeUrl">
        <el-input v-model="form.giteeUrl" placeholder="请输入码云地址" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="Github地址" prop="gitHubUrl">
        <el-input v-model="form.gitHubUrl" placeholder="请输入Github地址" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="CSDN博客地址" prop="cSDNUrl">
        <el-input v-model="form.cSDNUrl" placeholder="请输入CSDN博客地址" />
      </el-form-item>
    </el-col>
    <el-col :lg="12">
      <el-form-item label="邮箱" prop="email">
        <el-input v-model="form.email" placeholder="请输入邮箱" />
      </el-form-item>
    </el-col>
    <el-col :lg="24">
      <el-form-item label="头像" prop="avatar">
        <UploadImage v-model="form.avatar" column="avatar" @input="handleUploadSuccess" />
      </el-form-item>
    </el-col>

        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="text" @click="cancel">取 消</el-button>
        <el-button type="primary" @click="submitForm">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<script>
import { 
  listTBlogpersonalinfo,
  addTBlogpersonalinfo,
  delTBlogpersonalinfo,
  updateTBlogpersonalinfo,
  getTBlogpersonalinfo,
} from '@/api/blog/tBlogpersonalinfo.js';

export default {
  name: "tblogpersonalinfo",
  data() {
    return {
      labelWidth: "100px",
      formLabelWidth:"100px",
      // 选中id数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 遮罩层
      loading: false,
      // 显示搜索条件
      showSearch: true,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        sort: undefined,
        sortType: undefined,
      },
      // 弹出层标题
      title: "",
      // 操作类型 1、add 2、edit
      opertype: 0,
      // 是否显示弹出层
      open: false,
      // 表单参数
      form: {},
      columns: [
        { index: 0, key: 'id', label: ``, checked:  true  },
        { index: 1, key: 'name', label: `姓名`, checked:  true  },
        { index: 2, key: 'sex', label: `性别`, checked:  true  },
        { index: 3, key: 'age', label: `年龄`, checked:  true  },
        { index: 4, key: 'degree', label: `学历`, checked:  true  },
        { index: 5, key: 'height', label: `身高cm`, checked:  true  },
        { index: 6, key: 'weight', label: `体重kg`, checked:  true  },
        { index: 7, key: 'birthday', label: `出生日期`, checked:  true  },
        { index: 8, key: 'school', label: `学校`, checked:  true  },
        { index: 9, key: 'specialized', label: `专业`, checked:  false  },
        { index: 10, key: 'blood', label: `血型`, checked:  false  },
        { index: 11, key: 'giteeUrl', label: `码云地址`, checked:  false  },
        { index: 12, key: 'gitHubUrl', label: `Github地址`, checked:  false  },
        { index: 13, key: 'cSDNUrl', label: `CSDN博客地址`, checked:  false  },
        { index: 14, key: 'email', label: `邮箱`, checked:  false  },
        { index: 15, key: 'avatar', label: `头像`, checked:  false  },
      ],
      // 性别选项列表 格式 eg:{ dictLabel: '标签', dictValue: '0'}
      sexOptions: [],
      // 数据列表
      dataList: [],
      // 总记录数
      total: 0,
      // 提交按钮是否显示
      btnSubmitVisible: true,
      // 表单校验
      rules: {
      },
    };
  },
  created() {    
    // 列表数据查询
    this.getList();

    var dictParams = [
      { dictType: "sys_user_sex", columnName: "sexOptions" },
    ];
    this.getDicts(dictParams).then((response) => {
      response.data.forEach((element) => {
        this[element.columnName] = element.list;
      });
    });
  },
  methods: {
    // 查询数据
    getList() {
      this.loading = true;
      listTBlogpersonalinfo(this.queryParams).then(res => {
         if (res.code == 200) {
           this.dataList = res.data.result;
           this.total = res.data.totalNum;
           this.loading = false;
         }
       })
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 重置数据表单
    reset() {
      this.form = {
        name: undefined,
        sex: undefined,
        age: undefined,
        degree: undefined,
        height: undefined,
        weight: undefined,
        birthday: undefined,
        school: undefined,
        specialized: undefined,
        blood: undefined,
        giteeUrl: undefined,
        gitHubUrl: undefined,
        cSDNUrl: undefined,
        email: undefined,
        avatar: undefined,
      };
      this.resetForm("form");
    },
    // 重置查询操作
    resetQuery() {
      this.timeRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map((item) => item.id);
      this.single = selection.length != 1
      this.multiple = !selection.length;
    },
     // 自定义排序
    sortChange(column) {
      if (column.prop == null || column.order == null) {
        this.queryParams.sort = undefined;
        this.queryParams.sortType = undefined;
      } else {
        this.queryParams.sort = column.prop;
        this.queryParams.sortType = column.order;
      }

      this.handleQuery();
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加";
      this.opertype = 1;
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const Ids = row.id || this.ids;

      this.$confirm('是否确认删除参数编号为"' + Ids + '"的数据项？')
        .then(function () {
          return delTBlogpersonalinfo(Ids);
        })
        .then(() => {
          this.handleQuery();
          this.msgSuccess("删除成功");
        })
        .catch(() => {});
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids;
      getTBlogpersonalinfo(id).then((res) => {
        const { code, data } = res;
        if (code == 200) {
          this.open = true;
          this.title = "修改数据";
          this.opertype = 2;

          this.form = {
            ...data,
          };
        }
      });
    },
    //图片上传成功方法
    handleUploadSuccess(column, filelist) {
      this.form[column] = filelist;
    },
    // 性别字典翻译
    sexFormat(row, column) {
      return this.selectDictLabel(this.sexOptions, row.sex);
    },
    /** 提交按钮 */
    submitForm: function () {
      this.$refs["form"].validate((valid) => {
        if (valid) {
          console.log(JSON.stringify(this.form));
          
          if (this.form.id != undefined && this.opertype === 2) {
            updateTBlogpersonalinfo(this.form)
              .then((res) => {
                this.msgSuccess("修改成功");
                this.open = false;
                this.getList();
            })
            .catch((err) => {
                //TODO 错误逻辑
              });
          } else {
            addTBlogpersonalinfo(this.form)
              .then((res) => {
                this.msgSuccess("新增成功");
                this.open = false;
                this.getList();
            })
            .catch((err) => {
                //TODO 错误逻辑
              });
          }
        }
      });
    },
  },
};
</script>