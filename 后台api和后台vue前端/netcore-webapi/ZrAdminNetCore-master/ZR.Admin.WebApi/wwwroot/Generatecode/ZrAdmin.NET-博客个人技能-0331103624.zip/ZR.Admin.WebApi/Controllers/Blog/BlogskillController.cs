using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Infrastructure;
using Infrastructure.Attribute;
using Infrastructure.Enums;
using Infrastructure.Model;
using Mapster;
using ZR.Model.Dto;
using ZR.Model.Models;
using ZR.Service.Blog.IBlogService;
using ZR.Admin.WebApi.Extensions;
using ZR.Admin.WebApi.Filters;
using ZR.Common;
using Infrastructure.Extensions;
using System.Linq;

namespace ZR.Admin.WebApi.Controllers
{
    /// <summary>
    /// 博客个人技能Controller
    ///
    /// @author ztc
    /// @date 2022-03-31
    /// </summary>
    [Verify]
    [Route("Blog/TBlogskill")]
    public class BlogskillController : BaseController
    {
        /// <summary>
        /// 博客个人技能接口
        /// </summary>
        private readonly IBlogskillService _BlogskillService;

        public BlogskillController(IBlogskillService BlogskillService)
        {
            _BlogskillService = BlogskillService;
        }

        /// <summary>
        /// 查询博客个人技能列表
        /// </summary>
        /// <param name="parm"></param>
        /// <returns></returns>
        [HttpGet("list")]
        [ActionPermissionFilter(Permission = "blog:blogskill:list")]
        public IActionResult QueryBlogskill([FromQuery] BlogskillQueryDto parm)
        {
            var response = _BlogskillService.GetList(parm);
            return SUCCESS(response);
        }


        /// <summary>
        /// 查询博客个人技能详情
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet("{Id}")]
        [ActionPermissionFilter(Permission = "blog:blogskill:query")]
        public IActionResult GetBlogskill(int Id)
        {
            var response = _BlogskillService.GetFirst(x => x.Id == Id);
            
            return SUCCESS(response);
        }

        /// <summary>
        /// 添加博客个人技能
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ActionPermissionFilter(Permission = "blog:blogskill:add")]
        [Log(Title = "博客个人技能", BusinessType = BusinessType.INSERT)]
        public IActionResult AddBlogskill([FromBody] BlogskillDto parm)
        {
            if (parm == null)
            {
                throw new CustomException("请求参数错误");
            }
            //从 Dto 映射到 实体
            var modal = parm.Adapt<Blogskill>().ToCreate(HttpContext);

            var response = _BlogskillService.Insert(modal, it => new
            {
                it.Name,
                it.PicIcon,
                it.Des,
            });
            return ToResponse(response);
        }

        /// <summary>
        /// 更新博客个人技能
        /// </summary>
        /// <returns></returns>
        [HttpPut]
        [ActionPermissionFilter(Permission = "blog:blogskill:edit")]
        [Log(Title = "博客个人技能", BusinessType = BusinessType.UPDATE)]
        public IActionResult UpdateBlogskill([FromBody] BlogskillDto parm)
        {
            if (parm == null)
            {
                throw new CustomException("请求实体不能为空");
            }
            //从 Dto 映射到 实体
            var modal = parm.Adapt<Blogskill>().ToUpdate(HttpContext);

            var response = _BlogskillService.Update(w => w.Id == modal.Id, it => new Blogskill()
            {
                //Update 字段映射
                Name = modal.Name,
                PicIcon = modal.PicIcon,
                Des = modal.Des,
            });

            return ToResponse(response);
        }

        /// <summary>
        /// 删除博客个人技能
        /// </summary>
        /// <returns></returns>
        [HttpDelete("{ids}")]
        [ActionPermissionFilter(Permission = "blog:blogskill:delete")]
        [Log(Title = "博客个人技能", BusinessType = BusinessType.DELETE)]
        public IActionResult DeleteBlogskill(string ids)
        {
            int[] idsArr = Tools.SpitIntArrary(ids);
            if (idsArr.Length <= 0) { return ToResponse(ApiResult.Error($"删除失败Id 不能为空")); }

            var response = _BlogskillService.Delete(idsArr);

            return ToResponse(response);
        }


        /// <summary>
        /// 保存排序
        /// </summary>
        /// <param name="id">主键</param>
        /// <param name="value">排序值</param>
        /// <returns></returns>
        [ActionPermissionFilter(Permission = "blog:blogskill:edit")]
        [HttpGet("ChangeSort")]
        [Log(Title = "保存排序", BusinessType = BusinessType.UPDATE)]
        public IActionResult ChangeSort(int id = 0, int value = 0)
        {
            if (id <= 0) { return ToResponse(ApiResult.Error(101, "请求参数错误")); }
            var response = _BlogskillService.Update(w => w.Id == id, it => new Blogskill()
            {
                //Update 字段映射
                PicIcon = value,
            });
            
            return ToResponse(response);
        }
    }
}