import request from '@/utils/request'

/**
* 博客个人技能分页查询
* @param {查询条件} data
*/
export function listTBlogskill(query) {
  return request({
    url: 'Blog/TBlogskill/list',
    method: 'get',
    params: query,
  })
}


/**
* 新增博客个人技能
* @param data
*/
export function addTBlogskill(data) {
  return request({
    url: 'Blog/TBlogskill',
    method: 'post',
    data: data,
  })
}

/**
* 修改博客个人技能
* @param data
*/
export function updateTBlogskill(data) {
  return request({
    url: 'Blog/TBlogskill',
    method: 'PUT',
    data: data,
  })
}

/**
* 获取博客个人技能详情
* @param {Id}
*/
export function getTBlogskill(id) {
  return request({
    url: 'Blog/TBlogskill/' + id,
    method: 'get'
  })
}

/**
* 删除博客个人技能
* @param {主键} pid
*/
export function delTBlogskill(pid) {
  return request({
    url: 'Blog/TBlogskill/' + pid,
    method: 'delete'
  })
}

// 导出博客个人技能
export function exportTBlogskill(query) {
  return request({
    url: 'Blog/TBlogskill/export',
    method: 'get',
    params: query
  })
}

//排序
export function changeSort(data) {
  return request({
    url: 'Blog/TBlogskill/ChangeSort',
    method: 'get',
    params: data
  })
}
