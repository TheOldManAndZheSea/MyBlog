using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Infrastructure;
using Infrastructure.Attribute;
using Infrastructure.Enums;
using Infrastructure.Model;
using Mapster;
using ZR.Model.Dto;
using ZR.Model.Models;
using ZR.Service.Business.IBusinessService;
using ZR.Admin.WebApi.Extensions;
using ZR.Admin.WebApi.Filters;
using ZR.Common;
using Infrastructure.Extensions;
using System.Linq;

namespace ZR.Admin.WebApi.Controllers
{
    /// <summary>
    /// 博客前台配置表信息修改Controller
    ///
    /// @author ztc
    /// @date 2022-03-25
    /// </summary>
    [Verify]
    [Route("business/TBlogconfig")]
    public class BlogconfigController : BaseController
    {
        /// <summary>
        /// 博客前台配置表信息修改接口
        /// </summary>
        private readonly IBlogconfigService _BlogconfigService;

        public BlogconfigController(IBlogconfigService BlogconfigService)
        {
            _BlogconfigService = BlogconfigService;
        }

        /// <summary>
        /// 查询博客前台配置表信息修改列表
        /// </summary>
        /// <param name="parm"></param>
        /// <returns></returns>
        [HttpGet("list")]
        [ActionPermissionFilter(Permission = "business:blogconfig:list")]
        public IActionResult QueryBlogconfig([FromQuery] BlogconfigQueryDto parm)
        {
            var response = _BlogconfigService.GetList(parm);
            return SUCCESS(response);
        }


        /// <summary>
        /// 查询博客前台配置表信息修改详情
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet("{Id}")]
        [ActionPermissionFilter(Permission = "business:blogconfig:query")]
        public IActionResult GetBlogconfig(int Id)
        {
            var response = _BlogconfigService.GetFirst(x => x.Id == Id);
            
            return SUCCESS(response);
        }





    }
}