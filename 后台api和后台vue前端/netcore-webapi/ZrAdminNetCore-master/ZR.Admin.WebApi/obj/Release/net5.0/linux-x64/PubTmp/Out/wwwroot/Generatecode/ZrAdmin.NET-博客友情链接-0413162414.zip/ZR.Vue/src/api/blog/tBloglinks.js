import request from '@/utils/request'

/**
* 博客友情链接分页查询
* @param {查询条件} data
*/
export function listTBloglinks(query) {
  return request({
    url: 'Blog/TBloglinks/list',
    method: 'get',
    params: query,
  })
}


/**
* 新增博客友情链接
* @param data
*/
export function addTBloglinks(data) {
  return request({
    url: 'Blog/TBloglinks',
    method: 'post',
    data: data,
  })
}

/**
* 修改博客友情链接
* @param data
*/
export function updateTBloglinks(data) {
  return request({
    url: 'Blog/TBloglinks',
    method: 'PUT',
    data: data,
  })
}

/**
* 获取博客友情链接详情
* @param {Id}
*/
export function getTBloglinks(id) {
  return request({
    url: 'Blog/TBloglinks/' + id,
    method: 'get'
  })
}

/**
* 删除博客友情链接
* @param {主键} pid
*/
export function delTBloglinks(pid) {
  return request({
    url: 'Blog/TBloglinks/' + pid,
    method: 'delete'
  })
}

// 导出博客友情链接
export function exportTBloglinks(query) {
  return request({
    url: 'Blog/TBloglinks/export',
    method: 'get',
    params: query
  })
}

