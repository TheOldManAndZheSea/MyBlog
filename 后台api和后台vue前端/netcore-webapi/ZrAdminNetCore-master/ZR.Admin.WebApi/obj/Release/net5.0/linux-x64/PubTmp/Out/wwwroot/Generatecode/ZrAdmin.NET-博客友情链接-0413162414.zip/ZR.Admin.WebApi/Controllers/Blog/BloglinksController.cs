using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Infrastructure;
using Infrastructure.Attribute;
using Infrastructure.Enums;
using Infrastructure.Model;
using Mapster;
using ZR.Model.Dto;
using ZR.Model.Models;
using ZR.Service.Blog.IBlogService;
using ZR.Admin.WebApi.Extensions;
using ZR.Admin.WebApi.Filters;
using ZR.Common;
using Infrastructure.Extensions;
using System.Linq;

namespace ZR.Admin.WebApi.Controllers
{
    /// <summary>
    /// 博客友情链接Controller
    ///
    /// @author ztc
    /// @date 2022-04-13
    /// </summary>
    [Verify]
    [Route("Blog/TBloglinks")]
    public class BloglinksController : BaseController
    {
        /// <summary>
        /// 博客友情链接接口
        /// </summary>
        private readonly IBloglinksService _BloglinksService;

        public BloglinksController(IBloglinksService BloglinksService)
        {
            _BloglinksService = BloglinksService;
        }

        /// <summary>
        /// 查询博客友情链接列表
        /// </summary>
        /// <param name="parm"></param>
        /// <returns></returns>
        [HttpGet("list")]
        [ActionPermissionFilter(Permission = "blog:bloglinks:list")]
        public IActionResult QueryBloglinks([FromQuery] BloglinksQueryDto parm)
        {
            var response = _BloglinksService.GetList(parm);
            return SUCCESS(response);
        }


        /// <summary>
        /// 查询博客友情链接详情
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet("{Id}")]
        [ActionPermissionFilter(Permission = "blog:bloglinks:query")]
        public IActionResult GetBloglinks(int Id)
        {
            var response = _BloglinksService.GetFirst(x => x.Id == Id);
            
            return SUCCESS(response);
        }

        /// <summary>
        /// 添加博客友情链接
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ActionPermissionFilter(Permission = "blog:bloglinks:add")]
        [Log(Title = "博客友情链接", BusinessType = BusinessType.INSERT)]
        public IActionResult AddBloglinks([FromBody] BloglinksDto parm)
        {
            if (parm == null)
            {
                throw new CustomException("请求参数错误");
            }
            //从 Dto 映射到 实体
            var modal = parm.Adapt<Bloglinks>().ToCreate(HttpContext);

            var response = _BloglinksService.Insert(modal, it => new
            {
                it.Name,
                it.Links,
            });
            return ToResponse(response);
        }

        /// <summary>
        /// 更新博客友情链接
        /// </summary>
        /// <returns></returns>
        [HttpPut]
        [ActionPermissionFilter(Permission = "blog:bloglinks:edit")]
        [Log(Title = "博客友情链接", BusinessType = BusinessType.UPDATE)]
        public IActionResult UpdateBloglinks([FromBody] BloglinksDto parm)
        {
            if (parm == null)
            {
                throw new CustomException("请求实体不能为空");
            }
            //从 Dto 映射到 实体
            var modal = parm.Adapt<Bloglinks>().ToUpdate(HttpContext);

            var response = _BloglinksService.Update(w => w.Id == modal.Id, it => new Bloglinks()
            {
                //Update 字段映射
                Name = modal.Name,
                Links = modal.Links,
            });

            return ToResponse(response);
        }

        /// <summary>
        /// 删除博客友情链接
        /// </summary>
        /// <returns></returns>
        [HttpDelete("{ids}")]
        [ActionPermissionFilter(Permission = "blog:bloglinks:delete")]
        [Log(Title = "博客友情链接", BusinessType = BusinessType.DELETE)]
        public IActionResult DeleteBloglinks(string ids)
        {
            int[] idsArr = Tools.SpitIntArrary(ids);
            if (idsArr.Length <= 0) { return ToResponse(ApiResult.Error($"删除失败Id 不能为空")); }

            var response = _BloglinksService.Delete(idsArr);

            return ToResponse(response);
        }


    }
}