using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Infrastructure;
using Infrastructure.Attribute;
using Infrastructure.Enums;
using Infrastructure.Model;
using Mapster;
using ZR.Model.Dto;
using ZR.Model.Models;
using ZR.Service.Blog.IBlogService;
using ZR.Admin.WebApi.Extensions;
using ZR.Admin.WebApi.Filters;
using ZR.Common;
using Infrastructure.Extensions;
using System.Linq;

namespace ZR.Admin.WebApi.Controllers
{
    /// <summary>
    /// 博客个人信息Controller
    ///
    /// @author ztc
    /// @date 2022-03-29
    /// </summary>
    [Verify]
    [Route("Blog/TBlogpersonalinfo")]
    public class BlogpersonalinfoController : BaseController
    {
        /// <summary>
        /// 博客个人信息接口
        /// </summary>
        private readonly IBlogpersonalinfoService _BlogpersonalinfoService;

        public BlogpersonalinfoController(IBlogpersonalinfoService BlogpersonalinfoService)
        {
            _BlogpersonalinfoService = BlogpersonalinfoService;
        }

        /// <summary>
        /// 查询博客个人信息列表
        /// </summary>
        /// <param name="parm"></param>
        /// <returns></returns>
        [HttpGet("list")]
        [ActionPermissionFilter(Permission = "blog:blogpersonalinfo:list")]
        public IActionResult QueryBlogpersonalinfo([FromQuery] BlogpersonalinfoQueryDto parm)
        {
            var response = _BlogpersonalinfoService.GetList(parm);
            return SUCCESS(response);
        }


        /// <summary>
        /// 查询博客个人信息详情
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet("{Id}")]
        [ActionPermissionFilter(Permission = "blog:blogpersonalinfo:query")]
        public IActionResult GetBlogpersonalinfo(int Id)
        {
            var response = _BlogpersonalinfoService.GetFirst(x => x.Id == Id);
            
            return SUCCESS(response);
        }





    }
}