using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Infrastructure;
using Infrastructure.Attribute;
using Infrastructure.Enums;
using Infrastructure.Model;
using Mapster;
using ZR.Model.Dto;
using ZR.Model.Models;
using ZR.Service.Blog.IBlogService;
using ZR.Admin.WebApi.Extensions;
using ZR.Admin.WebApi.Filters;
using ZR.Common;
using Infrastructure.Extensions;
using System.Linq;

namespace ZR.Admin.WebApi.Controllers
{
    /// <summary>
    /// 文章类型Controller
    ///
    /// @author ztc
    /// @date 2022-03-30
    /// </summary>
    [Verify]
    [Route("Blog/Articlecategory")]
    public class ArticlecategoryController : BaseController
    {
        /// <summary>
        /// 文章类型接口
        /// </summary>
        private readonly IArticlecategoryService _ArticlecategoryService;

        public ArticlecategoryController(IArticlecategoryService ArticlecategoryService)
        {
            _ArticlecategoryService = ArticlecategoryService;
        }

        /// <summary>
        /// 查询文章类型列表
        /// </summary>
        /// <param name="parm"></param>
        /// <returns></returns>
        [HttpGet("list")]
        [ActionPermissionFilter(Permission = "blog:articlecategory:list")]
        public IActionResult QueryArticlecategory([FromQuery] ArticlecategoryQueryDto parm)
        {
            var response = _ArticlecategoryService.GetList(parm);
            return SUCCESS(response);
        }


        /// <summary>
        /// 查询文章类型详情
        /// </summary>
        /// <param name="CategoryId"></param>
        /// <returns></returns>
        [HttpGet("{CategoryId}")]
        [ActionPermissionFilter(Permission = "blog:articlecategory:query")]
        public IActionResult GetArticlecategory(int CategoryId)
        {
            var response = _ArticlecategoryService.GetFirst(x => x.CategoryId == CategoryId);
            
            return SUCCESS(response);
        }

        /// <summary>
        /// 添加文章类型
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ActionPermissionFilter(Permission = "blog:articlecategory:add")]
        [Log(Title = "文章类型", BusinessType = BusinessType.INSERT)]
        public IActionResult AddArticlecategory([FromBody] ArticlecategoryDto parm)
        {
            if (parm == null)
            {
                throw new CustomException("请求参数错误");
            }
            //从 Dto 映射到 实体
            var modal = parm.Adapt<Articlecategory>().ToCreate(HttpContext);

            var response = _ArticlecategoryService.Insert(modal, it => new
            {
                it.Name,
                it.CreateTime,
                it.ParentId,
                it.PicUrl,
                it.Color,
            });
            return ToResponse(response);
        }

        /// <summary>
        /// 更新文章类型
        /// </summary>
        /// <returns></returns>
        [HttpPut]
        [ActionPermissionFilter(Permission = "blog:articlecategory:edit")]
        [Log(Title = "文章类型", BusinessType = BusinessType.UPDATE)]
        public IActionResult UpdateArticlecategory([FromBody] ArticlecategoryDto parm)
        {
            if (parm == null)
            {
                throw new CustomException("请求实体不能为空");
            }
            //从 Dto 映射到 实体
            var modal = parm.Adapt<Articlecategory>().ToUpdate(HttpContext);

            var response = _ArticlecategoryService.Update(w => w.CategoryId == modal.CategoryId, it => new Articlecategory()
            {
                //Update 字段映射
                Name = modal.Name,
                ParentId = modal.ParentId,
                PicUrl = modal.PicUrl,
                Color = modal.Color,
            });

            return ToResponse(response);
        }

        /// <summary>
        /// 删除文章类型
        /// </summary>
        /// <returns></returns>
        [HttpDelete("{ids}")]
        [ActionPermissionFilter(Permission = "blog:articlecategory:delete")]
        [Log(Title = "文章类型", BusinessType = BusinessType.DELETE)]
        public IActionResult DeleteArticlecategory(string ids)
        {
            int[] idsArr = Tools.SpitIntArrary(ids);
            if (idsArr.Length <= 0) { return ToResponse(ApiResult.Error($"删除失败Id 不能为空")); }

            var response = _ArticlecategoryService.Delete(idsArr);

            return ToResponse(response);
        }


    }
}