using System;
using System.Collections.Generic;
using SqlSugar;
using OfficeOpenXml.Attributes;

namespace ZR.Model.Models
{
    /// <summary>
    /// 文章类型，数据实体对象
    ///
    /// @author ztc
    /// @date 2022-03-30
    /// </summary>
    [SugarTable("articlecategory")]
    public class Articlecategory
    {
        /// <summary>
        /// 描述 : 目录id
        /// 空值 : false  
        /// </summary>
        [SqlSugar.SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "category_id")]
        public int CategoryId { get; set; }

        /// <summary>
        /// 描述 : 目录名
        /// 空值 : false  
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 描述 : 创建时间
        /// 空值 : true  
        /// </summary>
        [SugarColumn(ColumnName = "create_time")]
        public DateTime? CreateTime { get; set; }

        /// <summary>
        /// 描述 : 父级ID
        /// 空值 : true  
        /// </summary>
        public int? ParentId { get; set; }

        /// <summary>
        /// 描述 : 图片
        /// 空值 : true  
        /// </summary>
        [SugarColumn(ColumnName = "pic_url")]
        public string PicUrl { get; set; }

        /// <summary>
        /// 描述 : 颜色
        /// 空值 : true  
        /// </summary>
        public string Color { get; set; }

    }
}