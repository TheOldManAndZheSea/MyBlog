import request from '@/utils/request'

/**
* 博客前台配置表信息修改分页查询
* @param {查询条件} data
*/
export function listTBlogconfig(query) {
  return request({
    url: 'business/TBlogconfig/list',
    method: 'get',
    params: query,
  })
}


/**
* 新增博客前台配置表信息修改
* @param data
*/
export function addTBlogconfig(data) {
  return request({
    url: 'business/TBlogconfig',
    method: 'post',
    data: data,
  })
}

/**
* 修改博客前台配置表信息修改
* @param data
*/
export function updateTBlogconfig(data) {
  return request({
    url: 'business/TBlogconfig',
    method: 'PUT',
    data: data,
  })
}

/**
* 获取博客前台配置表信息修改详情
* @param {Id}
*/
export function getTBlogconfig(id) {
  return request({
    url: 'business/TBlogconfig/' + id,
    method: 'get'
  })
}

/**
* 删除博客前台配置表信息修改
* @param {主键} pid
*/
export function delTBlogconfig(pid) {
  return request({
    url: 'business/TBlogconfig/' + pid,
    method: 'delete'
  })
}

// 导出博客前台配置表信息修改
export function exportTBlogconfig(query) {
  return request({
    url: 'business/TBlogconfig/export',
    method: 'get',
    params: query
  })
}

